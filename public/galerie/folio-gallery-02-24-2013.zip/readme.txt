1- Expand the zip file to your website's root or the folder of your choice. 

2- In the "albums" folder create a subfolder for each album and copy your photos in them.

3- Point to demo.php file in your browser. For example if you expanded your files to the 'folio-gallery' folder on your server:
http://youdomain.com/folio-gallery/demo.php

You can also just rename the "demo.php" file and point your browser to the renamed file.

"folio-gallery.php" file has some settings at the beginning which can be changed.

That's it!

NOTE: you must set the permissions for the 'albums' folder and all its subfolders to '777'  



This photo gallery will automatically create a thumbnail for each image as soon as you visit an album. 

A random thumbnail will be displayed for each album. 

The script will paginate the results automatically.

Integrated is lightbox clone 'fancybox' from www.fancybox.net. 

For more info please visit:
www.FolioPages.com/php-photo-gallery 

Harry G
info@foliopages.com  
  